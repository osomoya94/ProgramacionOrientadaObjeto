package trabajoEntregar;

public class Main {
    public static void main(String[] args) {
        Vehiculo miCoche = new Vehiculo( 180f, 45.5f, 50f);

        miCoche.MostrarInformacion();

    }
}